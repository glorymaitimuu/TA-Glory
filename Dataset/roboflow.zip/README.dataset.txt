# Acne > 2024-10-15 9:25am
https://universe.roboflow.com/gloria-fzhfs/acne-zvxww

Provided by a Roboflow user
License: CC BY 4.0

